# Backlog → Google Calendar Helper v0.4.6

## 概要

Backlog課題をGoogleカレンダーまたはTaskに素早く登録するChrome拡張です。

## 起動方法

- `Cmd + Shift + L` / `Ctrl + Shift + L`
  - Calendar mode
  - 通常のGoogleカレンダー予定作成用
- `Cmd + Shift + K` / `Ctrl + Shift + K`
  - Task mode
  - Google Tasks向け
  - タスクタブへの自動切替と入力を行う

## ショートカット設定

Chromeの仕様上、ショートカットが自動割り当てされない場合があります。
その場合は `chrome://extensions/shortcuts` から確認・設定してください。

## 使い分け

- Task（Cmd + Shift + K）
  - 作業候補・メモとして積む
  - カレンダーを汚さない / 表示させたくないもの
- Calendar（Cmd + Shift + L）
  - 時間ブロックが必要な作業
  - カレンダーを見ることができる他者にスケジュール公開される前提

## 現状の挙動

- Backlog課題ページでショートカットキーを押す
- 課題キー・件名・URLを取得
- 拡張ストレージに `mode` 付きで一時保存
- 既存のGoogleカレンダータブ / ウィンドウがあれば再利用
- なければGoogleカレンダーを開く
- Googleカレンダー側で新規作成フォームが開くと、Calendarは件名・説明欄、Taskはタイトル・詳細欄へ自動入力
- 手動貼り付け用として、可能な場合は課題情報をクリップボードにもコピー

## インストール

1. ZIPを展開する
2. `chrome://extensions/` を開く
3. デベロッパーモードをONにする
4. 「パッケージ化されていない拡張機能を読み込む」を選ぶ
5. 展開したこのフォルダを指定する
6. 必要に応じて `chrome://extensions/shortcuts` でショートカットを確認する

## トラブルシューティング

### `Extension context invalidated` と表示される / 更新後に動かない

拡張機能を更新・再読み込みしたあと、更新前から開いていたBacklogやGoogle Calendarのタブには古いcontent scriptが残ることがあります。

1. Backlogの課題ページを再読み込みする
2. Google Calendarを再読み込みする
3. 改善しない場合はGoogle Calendarのタブを閉じて開き直す
4. その後、再度ショートカットを実行する

特に `chrome://extensions/` から拡張機能を「更新」「再読み込み」した直後は、既存タブも再読み込みしてください。

### ショートカットが効かない

`chrome://extensions/shortcuts` を開き、Calendar / Taskのショートカットが割り当てられているか確認してください。OSや他の拡張機能のショートカットと競合する場合があります。

### Calendar / Taskへ自動入力されない

まずBacklogの課題ページとGoogle Calendarの両方を再読み込みしてから、再度実行してください。

Google CalendarのUI / DOM変更により入力欄の構造が変わると、拡張側の修正が必要になる場合があります。

### クリップボードへのコピーに失敗する

ブラウザのフォーカス状態などにより、クリップボード書き込みが拒否される場合があります。v0.4.6では、クリップボードへのコピーが失敗しても、課題情報の一時保存とCalendar / Taskへの連携は継続します。

## v0.4.6の主な修正

- Google Calendarの説明欄が `aria-labelledby="xDescIn-label"` を使うDOMに変更されたことへ対応
- クリップボード書き込みが失敗してもCalendar / Task連携を停止しないよう修正
- Backlog課題タイトル内のハイフンを区切りと誤認して件名が途中で切れる問題を修正

## 注意事項

- Google Calendarの公開APIではなく画面DOMを利用して入力を補助しているため、Google CalendarのUI変更で動作しなくなる可能性があります
- この拡張はChrome Web Storeで正式配布しているものではありません
